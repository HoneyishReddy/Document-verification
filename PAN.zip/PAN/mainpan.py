import subprocess

# Run removebg.py
subprocess.run(['python', 'PAN/removebg.py'])

# Run check.py
subprocess.run(['python', 'PAN/check.py'])
